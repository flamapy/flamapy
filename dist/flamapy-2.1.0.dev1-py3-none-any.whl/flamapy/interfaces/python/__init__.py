from .flamapy_feature_model import FLAMAFeatureModel

__all__ = ["FLAMAFeatureModel"]
